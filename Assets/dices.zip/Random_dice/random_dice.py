import tkinter as tk
import random
#from PI#L import Image



window = tk.Tk()

#dice1 = tk.PhotoImage(dice1.open('dice_1.png'))
#dice2 = tk.PhotoImage(file='dice_2.png')
#dice3 = tk.PhotoImage(file='dice_3.png')
#dice4 = tk.PhotoImage(file='dice_4.png')
#dice5 = tk.PhotoImage(file='dice_5.png')
#dice6 = tk.PhotoImage(file='dice_6.png')

def random_int():
    #value = int(value_lbl["text"])
    value_lbl["text"] = random.randint(1,12)

roll_btn = tk.Button(
    text = "Roll dices",
    fg = "blue",
    command = random_int
)

home = tk.Radiobutton(window, text='Home')

value_lbl = tk.Label(
    text = "0"
)


roll_btn.pack()
#home.pack()
value_lbl.pack()


window.mainloop()